using Xunit;
using Moq;
using System.Collections.Generic;
using art_api.Persistence;
using Npgsql;
using art_api.Models;
using MongoDB.Driver;
using MongoDB.Bson;
using art_api.Settings;
using Microsoft.Extensions.Options;
using MongoDB.Bson.Serialization.Attributes;

public class ArtifactTypeRepositoryTests
{
    private readonly ArtifactTypeRepository _artifactTypeRepo;

    // Test for returning all artifact types
    [Fact]
    public async Task GetArtifactTypes_ReturnsAllArtifactTypes()
    {
        // Arrange
        var artifactTypes = new List<ArtifactType>
        {
            new ArtifactType
            {
                Id = "1",
                Title = "Sculpture",
                Description = "Three-dimensional artworks carved or molded from various materials."
            }
        };

        // 1. Mock IAsyncCursor<ArtifactType>
        var mockCursor = new Mock<IAsyncCursor<ArtifactType>>();
        mockCursor.Setup(_ => _.Current).Returns(artifactTypes);
        mockCursor.SetupSequence(_ => _.MoveNext(It.IsAny<CancellationToken>()))
                .Returns(true)
                .Returns(false); // End the enumeration

        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(true)
                .ReturnsAsync(false); // For async

        // 2. Mock IMongoCollection<ArtifactType>
        var mockCollection = new Mock<IMongoCollection<ArtifactType>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<ArtifactType>>(),
                It.IsAny<FindOptions<ArtifactType, ArtifactType>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);


        // Set up the mock client and settings
        var mockClient = new Mock<IMongoClient>();
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<ArtifactType>("artifacttypes", null))
                    .Returns(mockCollection.Object);

        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "artifacttypes",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ArtifactTypeRepository(options, mockClient.Object);

        // Act
        var result = await repo.GetAllAsync();

        // Assert
        Assert.Single(result);
        Assert.Equal("Sculpture", result[0].Title);
    }


    // Test for returning artifact types by id
    [Fact]
    public async Task GetArtifactTypeByID_ReturnsCorrectArtifactType()
    {
        // Arrange
        var artifactTypes = new List<ArtifactType>
        {
            new ArtifactType
            {
                Id = "1",
                Title = "Sculpture",
                Description = "Three-dimensional artworks carved or molded from various materials."
            }
        };

         // 1. Mock IAsyncCursor<ArtifactType>
        var mockCursor = new Mock<IAsyncCursor<ArtifactType>>();
        mockCursor.Setup(_ => _.Current).Returns(artifactTypes);
        mockCursor.SetupSequence(_ => _.MoveNext(It.IsAny<CancellationToken>()))
                .Returns(true)
                .Returns(false); // End the enumeration

        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(true)
                .ReturnsAsync(false); // For async

        // 2. Mock IMongoCollection<ArtifactType>
        var mockCollection = new Mock<IMongoCollection<ArtifactType>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<ArtifactType>>(),
                It.IsAny<FindOptions<ArtifactType, ArtifactType>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);


        // Set up the mock client and settings
        var mockClient = new Mock<IMongoClient>();
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<ArtifactType>("artifacttypes", null))
                    .Returns(mockCollection.Object);

        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "artifacttypes",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ArtifactTypeRepository(options, mockClient.Object);

        // Act
        var result = await repo.GetByIdAsync("1");  

        // Assert
        Assert.NotNull(result);
        Assert.Equal("Sculpture", result.Title);
    }

    // Test for returning artifact types by id but designed to fail since it's not found
    [Fact]
    public async Task GetArtifactTypeByID_ReturnsNullIfNotFound()
    {
        // 1. Mock IAsyncCursor<ArtifactType>
        var mockCursor = new Mock<IAsyncCursor<ArtifactType>>();
        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(false); // End the enumeration & async

        // Even though MoveNextAsync returns false, MongoDB driver might still access Current, so it must be set
        mockCursor.SetupGet(_ => _.Current).Returns(new List<ArtifactType>());

        // 2. Mock IMongoCollection<ArtifactType>
        var mockCollection = new Mock<IMongoCollection<ArtifactType>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<ArtifactType>>(),
                It.IsAny<FindOptions<ArtifactType, ArtifactType>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        // Set up the mock client and settings
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<ArtifactType>("artifacttypes", null))
                    .Returns(mockCollection.Object);

        var mockClient = new Mock<IMongoClient>();
        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "artifactTypes",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ArtifactTypeRepository(options, mockClient.Object);

        // Act
        var result = await repo.GetByIdAsync("99");

        // Assert
        Assert.Null(result);
    }

    // Test for inserting new artifact type into DB
    [Fact]
    public async Task InsertArtifactTypes_InsertsAndReturnsArtifactType_WhenNotExists()
    {
        // Arrange
        var artifactTypeToUpdate = new ArtifactType
        {
            Id = "1",
            Title = "Sculpture",
            Description = "Three-dimensional artworks carved or molded from various materials."
        };

        // 1. Mock IAsyncCursor<ArtifactType>
        var mockCursor = new Mock<IAsyncCursor<ArtifactType>>();
        mockCursor.Setup(_ => _.Current).Returns(new List<ArtifactType>());
        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(true)
                .ReturnsAsync(false); // End the enumeration & async

        // 2. Mock IMongoCollection<Artifact>
        var mockCollection = new Mock<IMongoCollection<ArtifactType>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<ArtifactType>>(),
                It.IsAny<FindOptions<ArtifactType, ArtifactType>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        mockCollection.Setup(c => c.ReplaceOneAsync(
                It.IsAny<FilterDefinition<ArtifactType>>(),
                artifactTypeToUpdate,
                It.IsAny<ReplaceOptions>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(new ReplaceOneResult.Acknowledged(1, 1, artifactTypeToUpdate.Id));

        // Set up the mock client and settings
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<ArtifactType>("artifacttypes", null))
                    .Returns(mockCollection.Object);

        var mockClient = new Mock<IMongoClient>();
        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "artifacttypes",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ArtifactTypeRepository(options, mockClient.Object);
        
        // Act
        var result = await repo.InsertAsync(artifactTypeToUpdate, false);

        // Assert
        Assert.NotNull(result);
        Assert.Equal("Sculpture", result.Title);
    }

    // Test for inserting new artifact type into DB but it already exists
    [Fact]
    public async Task InsertArtifactTypes_ReturnsNull_WhenArtifactTypeAlreadyExists()
    {
        // Arrange
        var existingArtifactType = new ArtifactType
        {
            Id = "1",
            Title = "Sculpture",
            Description = "Three-dimensional artworks carved or molded from various materials."
        };
        var artifactTypeToUpdate = new ArtifactType
        {
            Id = "2",
            Title = "Painting",
            Description = "Artworks created using pigments on a surface such as canvas or wood."
        };

        // 1. Mock IAsyncCursor<ArtifactType>
        var mockCursor = new Mock<IAsyncCursor<ArtifactType>>();
        mockCursor.Setup(_ => _.Current).Returns(new List<ArtifactType> { existingArtifactType });
        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(true)
                .ReturnsAsync(false); // End the enumeration & async

        // 2. Mock IMongoCollection<ArtifactType>
        var mockCollection = new Mock<IMongoCollection<ArtifactType>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<ArtifactType>>(),
                It.IsAny<FindOptions<ArtifactType, ArtifactType>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        // Set up the mock client and settings
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<ArtifactType>("artifacttypes", null))
                    .Returns(mockCollection.Object);

        var mockClient = new Mock<IMongoClient>();
        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "artifacttypes",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ArtifactTypeRepository(options, mockClient.Object);
        
        // Act
        var result = await repo.InsertAsync(existingArtifactType, false);

        // Assert
        Assert.Null(result); 
    }

    //Test to update artifact type that exists
    [Fact]
    public async void UpdateArtifactTypes_UpdatesAndReturnsArtifactType()
    {
        // Arrange
        var artifactTypeToUpdate = new ArtifactType
        {
            Id = "1",
            Title = "Sculpture",
            Description = "Three-dimensional artworks carved or molded from various materials."
        };

        // 1. Mock IAsyncCursor<ArtifactType>
        var mockCursor = new Mock<IAsyncCursor<ArtifactType>>();
        mockCursor.Setup(_ => _.Current).Returns(new List<ArtifactType>());
        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(true)
                .ReturnsAsync(false); // End the enumeration

        // 2. Mock IMongoCollection<ArtifactType>
        var mockCollection = new Mock<IMongoCollection<ArtifactType>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<ArtifactType>>(),
                It.IsAny<FindOptions<ArtifactType, ArtifactType>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        mockCollection.Setup(c => c.ReplaceOneAsync(
                It.IsAny<FilterDefinition<ArtifactType>>(),
                artifactTypeToUpdate,
                It.IsAny<ReplaceOptions>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(new ReplaceOneResult.Acknowledged(1, 1, artifactTypeToUpdate.Id));

        // Set up the mock client and settings
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<ArtifactType>("artifacttypes", null))
                    .Returns(mockCollection.Object);

        var mockClient = new Mock<IMongoClient>();
        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "artifacttypes",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ArtifactTypeRepository(options, mockClient.Object);

        // Act
        var result = await repo.UpdateAsync(artifactTypeToUpdate, false);

        // Assert
        Assert.NotNull(result);
        Assert.Equal("Sculpture", result.Title);
    }

    // Updates artifact type but returns null since it doesn't exist
    [Fact]
    public async void UpdateArtifactTypes_ReturnsNull_OnException()
    {
        // Arrange
        var artifactType = new ArtifactType
        {
            Id = "1",
            Title = "Sculpture",
            Description = "Three-dimensional artworks carved or molded from various materials."
        };
        var artifactTypeToUpdate = new ArtifactType
        {
            Id = "2",
            Title = "Painting",
            Description = "Artworks created using pigments on a surface such as canvas or wood."
        };

        // 1. Mock IAsyncCursor<ArtifactType>
        var mockCursor = new Mock<IAsyncCursor<ArtifactType>>();
        mockCursor.Setup(_ => _.Current).Returns(new List<ArtifactType> {artifactType});
        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(true)
                .ReturnsAsync(false); // End the enumeration & async

        // 2. Mock IMongoCollection<ArtifactType>
        var mockCollection = new Mock<IMongoCollection<ArtifactType>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<ArtifactType>>(),
                It.IsAny<FindOptions<ArtifactType, ArtifactType>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        mockCollection.Setup(c => c.ReplaceOneAsync(
                It.IsAny<FilterDefinition<ArtifactType>>(),
                artifactTypeToUpdate,
                It.IsAny<ReplaceOptions>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(new ReplaceOneResult.Acknowledged(1, 1, artifactTypeToUpdate.Id));

        // Set up the mock client and settings
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<ArtifactType>("artifacttypes", null))
                    .Returns(mockCollection.Object);

        var mockClient = new Mock<IMongoClient>();
        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "artifacttypes",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ArtifactTypeRepository(options, mockClient.Object);

        // Act
        var result = await repo.UpdateAsync(artifactTypeToUpdate, false);

        // Assert
        Assert.Null(result); 
    }

    // Test for deleting artifact type
    [Fact]
    public async Task DeleteArtifactTypes_DeletesArtifactType()
    {
        // Arrange: Mock empty cursor for FindAsync (no artifactType found)
        var mockCursor = new Mock<IAsyncCursor<ArtifactType>>();
        mockCursor.Setup(_ => _.Current).Returns(new List<ArtifactType>());
        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(true)
                .ReturnsAsync(false);

        // Mock IMongoCollection<ArtifactType>
        var mockCollection = new Mock<IMongoCollection<ArtifactType>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<ArtifactType>>(),
                It.IsAny<FindOptions<ArtifactType, ArtifactType>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        // Mock DeleteOneAsync to return a successful DeleteResult
        mockCollection.Setup(c => c.DeleteOneAsync(
                It.IsAny<FilterDefinition<ArtifactType>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Mock.Of<DeleteResult>(r => r.IsAcknowledged == true && r.DeletedCount == 1));

        // Set up the mock client and settings
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<ArtifactType>("artifacttypes", null))
                    .Returns(mockCollection.Object);

        var mockClient = new Mock<IMongoClient>();
        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "artifacttypes",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ArtifactTypeRepository(options, mockClient.Object);

        // Act
        await repo.DeleteAsync("1");

        // Assert: Verify DeleteOneAsync was called once with correct filter
        mockCollection.Verify(c => c.DeleteOneAsync(
            It.Is<FilterDefinition<ArtifactType>>(f => true),  
            It.IsAny<CancellationToken>()), Times.Once);
    }
}