using Xunit;
using Moq;
using System.Collections.Generic;
using art_api.Persistence;
using Npgsql;
using art_api.Models;
using MongoDB.Driver;
using MongoDB.Bson;
using art_api.Settings;
using Microsoft.Extensions.Options;
using MongoDB.Bson.Serialization.Attributes;

public class ArtistRepositoryTests
{
    private readonly ArtistRepository _artistRepo;

    // Test for returning all artists
    [Fact]
    public async Task GetArtists_ReturnsAllArtists()
    {
        // Arrange
        var artists = new List<Artist>
        {
            new Artist { Id = "1", Name = "Test Artist", DOB = 1980 }
        };

        // 1. Mock IAsyncCursor<Artist>
        var mockCursor = new Mock<IAsyncCursor<Artist>>();
        mockCursor.Setup(_ => _.Current).Returns(artists);
        mockCursor.SetupSequence(_ => _.MoveNext(It.IsAny<CancellationToken>()))
                .Returns(true)
                .Returns(false); // End the enumeration

        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(true)
                .ReturnsAsync(false); // For async

        // 2. Mock IMongoCollection<Artist>
        var mockCollection = new Mock<IMongoCollection<Artist>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<Artist>>(),
                It.IsAny<FindOptions<Artist, Artist>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        // Set up the mock client and settings
        var mockClient = new Mock<IMongoClient>();
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<Artist>("artists", null))
                    .Returns(mockCollection.Object);

        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "artists",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ArtistRepository(options, mockClient.Object);

        // Act
        var result = await repo.GetAllAsync();

        // Assert
        Assert.Single(result);
        Assert.Equal("Test Artist", result[0].Name);
    }

    // Test for returning artists by id
    [Fact]
    public async Task GetArtistByID_ReturnsCorrectArtist()
    {
        // Arrange
        var artist = new Artist { Id = "1", Name = "Test" };
        var artistList = new List<Artist> { artist };

        // 1. Mock IAsyncCursor<Artist>
        var mockCursor = new Mock<IAsyncCursor<Artist>>();
        mockCursor.Setup(_ => _.Current).Returns(artistList);  // Must return IEnumerable<Artist>
        mockCursor.SetupSequence(_ => _.MoveNext(It.IsAny<CancellationToken>()))
                .Returns(true)
                .Returns(false); // End the enumeration

        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(true)
                .ReturnsAsync(false); // For async

        // 2. Mock IMongoCollection<Artist>
        var mockCollection = new Mock<IMongoCollection<Artist>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<Artist>>(),
                It.IsAny<FindOptions<Artist, Artist>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        // Set up the mock client and settings
        var mockClient = new Mock<IMongoClient>();
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<Artist>("artists", null))
                    .Returns(mockCollection.Object);
        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "artists",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ArtistRepository(options, mockClient.Object);

        // Act
        var result = await repo.GetByIdAsync("1");  // ✅ Use `repo` and await it

        // Assert
        Assert.NotNull(result);
        Assert.Equal("Test", result.Name);
    }

    // Test for returning artists by id but designed to fail since it's not found
    [Fact]
    public async Task GetArtistByID_ReturnsNullIfNotFound()
    {
        // 1. Mock IAsyncCursor<Artist>
        var mockCursor = new Mock<IAsyncCursor<Artist>>();
        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(false); // End the enumeration & async

        // Even though MoveNextAsync returns false, MongoDB driver might still access Current, so it must be set
        mockCursor.SetupGet(_ => _.Current).Returns(new List<Artist>());

        // 2. Mock IMongoCollection<Artist>
        var mockCollection = new Mock<IMongoCollection<Artist>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<Artist>>(),
                It.IsAny<FindOptions<Artist, Artist>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        // Set up the mock client and settings
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<Artist>("artists", null))
                    .Returns(mockCollection.Object);

        var mockClient = new Mock<IMongoClient>();
        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "artists",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ArtistRepository(options, mockClient.Object);

        // Act
        var result = await repo.GetByIdAsync("99");

        // Assert
        Assert.Null(result);
    }

    // Test for inserting new artist into DB
    [Fact]
    public async Task InsertArtists_InsertsAndReturnsArtist_WhenNotExists()
    {
        // Arrange
        var artistToUpdate = new Artist { Id = "1", Name = "Updated", DOB = 1995 };

        // 1. Mock IAsyncCursor<Artist>
        var mockCursor = new Mock<IAsyncCursor<Artist>>();
        mockCursor.Setup(_ => _.Current).Returns(new List<Artist>());
        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(true)
                .ReturnsAsync(false); // End the enumeration & async

        // 2. Mock IMongoCollection<Artist>
        var mockCollection = new Mock<IMongoCollection<Artist>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<Artist>>(),
                It.IsAny<FindOptions<Artist, Artist>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        mockCollection.Setup(c => c.ReplaceOneAsync(
                It.IsAny<FilterDefinition<Artist>>(),
                artistToUpdate,
                It.IsAny<ReplaceOptions>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(new ReplaceOneResult.Acknowledged(1, 1, artistToUpdate.Id));

        // Set up the mock client and settings
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<Artist>("artists", null))
                    .Returns(mockCollection.Object);

        var mockClient = new Mock<IMongoClient>();
        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "artists",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ArtistRepository(options, mockClient.Object);
        
        // Act
        var result = await repo.InsertAsync(artistToUpdate, false);

        // Assert
        Assert.NotNull(result);
        Assert.Equal("Updated", result.Name);
    }

    // Test for inserting new artist into DB but it already exists
    [Fact]
    public async Task InsertArtists_ReturnsNull_WhenArtistAlreadyExists()
    {
        // Arrange
        var existingArtist = new Artist { Id = "99", Name = "Existing", DOB = 1980 };
        var artistToUpdate = new Artist { Id = "1", Name = "Existing", DOB = 1995 };

        // 1. Mock IAsyncCursor<Artist>
        var mockCursor = new Mock<IAsyncCursor<Artist>>();
        mockCursor.Setup(_ => _.Current).Returns(new List<Artist> { existingArtist });
        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(true)
                .ReturnsAsync(false); // End the enumeration & async

        // 2. Mock IMongoCollection<Artist>
        var mockCollection = new Mock<IMongoCollection<Artist>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<Artist>>(),
                It.IsAny<FindOptions<Artist, Artist>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        // Set up the mock client and settings
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<Artist>("artists", null))
                    .Returns(mockCollection.Object);

        var mockClient = new Mock<IMongoClient>();
        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "artists",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ArtistRepository(options, mockClient.Object);
        
        // Act
        var result = await repo.InsertAsync(existingArtist, false);

        // Assert
        Assert.Null(result); 
    }

    //Test to update artist that exists
    [Fact]
    public async void UpdateArtists_UpdatesAndReturnsArtist()
    {
        // Arrange
        var artistToUpdate = new Artist { Id = "1", Name = "Updated", DOB = 1995 };

        // 1. Mock IAsyncCursor<Artist>
        var mockCursor = new Mock<IAsyncCursor<Artist>>();
        mockCursor.Setup(_ => _.Current).Returns(new List<Artist>());
        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(true)
                .ReturnsAsync(false); // End the enumeration & async

        // 2. Mock IMongoCollection<Artist>
        var mockCollection = new Mock<IMongoCollection<Artist>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<Artist>>(),
                It.IsAny<FindOptions<Artist, Artist>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        mockCollection.Setup(c => c.ReplaceOneAsync(
                It.IsAny<FilterDefinition<Artist>>(),
                artistToUpdate,
                It.IsAny<ReplaceOptions>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(new ReplaceOneResult.Acknowledged(1, 1, artistToUpdate.Id));

        // Set up the mock client and settings
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<Artist>("artists", null))
                    .Returns(mockCollection.Object);

        var mockClient = new Mock<IMongoClient>();
        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "artists",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ArtistRepository(options, mockClient.Object);

        // Act 
        var result = await repo.UpdateAsync(artistToUpdate, false);

        // Assert
        Assert.NotNull(result);
        Assert.Equal("Updated", result.Name);
    }

    // Updates artist but returns null since it doesn't exist
    [Fact]
    public async void UpdateArtists_ReturnsNull_OnException()
    {
        // Arrange
        var artist = new Artist { Id = "99", Name = "Broken", DOB = 1980 };
        var artistToUpdate = new Artist { Id = "1", Name = "Updated", DOB = 1995 };

        // 1. Mock IAsyncCursor<Artist>
        var mockCursor = new Mock<IAsyncCursor<Artist>>();
        mockCursor.Setup(_ => _.Current).Returns(new List<Artist> {artist});
        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(true)
                .ReturnsAsync(false); // End the enumeration & async

        // 2. Mock IMongoCollection<Artist>
        var mockCollection = new Mock<IMongoCollection<Artist>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<Artist>>(),
                It.IsAny<FindOptions<Artist, Artist>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        mockCollection.Setup(c => c.ReplaceOneAsync(
                It.IsAny<FilterDefinition<Artist>>(),
                artistToUpdate,
                It.IsAny<ReplaceOptions>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(new ReplaceOneResult.Acknowledged(1, 1, artistToUpdate.Id));

        // Set up the mock client and settings
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<Artist>("artists", null))
                    .Returns(mockCollection.Object);

        var mockClient = new Mock<IMongoClient>();
        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "artists",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ArtistRepository(options, mockClient.Object);

        // Act
        var result = await repo.UpdateAsync(artistToUpdate, false);

        // Assert
        Assert.Null(result); 
    }

    // Test for deleting artist
    [Fact]
    public async Task DeleteArtists_DeletesArtist()
    {
        // Arrange: Mock empty cursor for FindAsync (no artist found)
        var mockCursor = new Mock<IAsyncCursor<Artist>>();
        mockCursor.Setup(_ => _.Current).Returns(new List<Artist>());
        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(true)
                .ReturnsAsync(false);

        // Mock IMongoCollection<Artist>
        var mockCollection = new Mock<IMongoCollection<Artist>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<Artist>>(),
                It.IsAny<FindOptions<Artist, Artist>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        // Mock DeleteOneAsync to return a successful DeleteResult
        mockCollection.Setup(c => c.DeleteOneAsync(
                It.IsAny<FilterDefinition<Artist>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Mock.Of<DeleteResult>(r => r.IsAcknowledged == true && r.DeletedCount == 1));

        // Mock database and client
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<Artist>("artists", null))
                    .Returns(mockCollection.Object);

        // Set up the mock client and settings
        var mockClient = new Mock<IMongoClient>();
        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "artists",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ArtistRepository(options, mockClient.Object);

        // Act
        await repo.DeleteAsync("1");

        // Assert: Verify DeleteOneAsync was called once with correct filter
        mockCollection.Verify(c => c.DeleteOneAsync(
            It.Is<FilterDefinition<Artist>>(f => true),  // you can refine this to match id "1"
            It.IsAny<CancellationToken>()), Times.Once);
    }

    // Test getting artists by community
    [Fact]
    public async void GetArtistsByCommunity_ReturnsMatchingArtists()
    {
        // Arrange
        var artist = new Artist { Id = "1", Name = "Test", Community = "c" };
        var artistList = new List<Artist> { artist };

        // 1. Mock IAsyncCursor<Artist>
        var mockCursor = new Mock<IAsyncCursor<Artist>>();
        mockCursor.Setup(_ => _.Current).Returns(artistList);  // Must return IEnumerable<Artist>
        mockCursor.SetupSequence(_ => _.MoveNext(It.IsAny<CancellationToken>()))
                .Returns(true)
                .Returns(false);
        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(true)
                .ReturnsAsync(false); // End the enumeration & async

        // 2. Mock IMongoCollection<Artist>
        var mockCollection = new Mock<IMongoCollection<Artist>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<Artist>>(),
                It.IsAny<FindOptions<Artist, Artist>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        // Set up the mock client and settings
        var mockClient = new Mock<IMongoClient>();
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<Artist>("artists", null))
                    .Returns(mockCollection.Object);
        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "artists",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ArtistRepository(options, mockClient.Object);

        // Act
        var result = await repo.GetByCommunityAsync("c"); 

        // Assert
        Assert.Single(result);
        Assert.Equal("Test", result[0].Name);
    }
}
