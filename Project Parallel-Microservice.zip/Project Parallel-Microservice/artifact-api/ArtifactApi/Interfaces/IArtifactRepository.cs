using art_api.Models;

namespace art_api.Persistence
{
    public interface IArtifactRepository
    {
        Task<Artifact?> GetByTitleAsync(string Title);
        Task<Artifact> InsertAsync(Artifact artifact, bool isChecked);
        Task<List<Artifact>> GetAllAsync();    
        Task<Artifact?> GetByIdAsync(string id);    
        Task<Artifact?> UpdateAsync(Artifact artifact, bool isChecked);
        Task<bool> DeleteAsync(string id);
        Task<List<Artifact>> GetFilteredArtifactsAsync(bool? framed, bool? @new, bool? staffPick);
        Task<List<Artifact>> GetArtifactsByTypeAsync(string typeTitle);
    }
}