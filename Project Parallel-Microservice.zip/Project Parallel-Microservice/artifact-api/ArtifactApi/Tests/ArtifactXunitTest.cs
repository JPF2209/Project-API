using Xunit;
using Moq;
using System.Collections.Generic;
using art_api.Persistence;
using Npgsql;
using art_api.Models;
using MongoDB.Driver;
using MongoDB.Bson;
using art_api.Settings;
using Microsoft.Extensions.Options;
using MongoDB.Bson.Serialization.Attributes;

public class ArtifactRepositoryTests
{
    private readonly ArtifactRepository _artifactRepo;

    // Test for returning all artifacts
    [Fact]
    public async Task GetArtifacts_ReturnsAllArtifacts()
    {
        // Arrange
        var artifacts = new List<Artifact>
        {
            new Artifact
            {
                Id = "1",
                Title = "Exhibit A",
                ArtistId = "101",
                Artist = new Artist { Id = "101", Name = "Alice Walker" },
                ProductNo = "A001",
                Framed = true,
                Size = "24x36",
                Medium = "Oil on Canvas",
                Price = 1200.00,
                SalePrice = 1000.00,
                OnSale = true,
                TypeId = "1",
                Type = new ArtifactType { Id = "1", Title = "Painting", Description = "Pigments on canvas or wood" },
                Colour = "Blue",
                Shape = "Rectangle",
                New = false,
                StaffPicks = true,
                ExhibitionId = "201",
                Exhibition = new Exhibition { Id = "201", Title = "Winter Collection" }
            }
        };

        // 1. Mock IAsyncCursor<Artifact>
        var mockCursor = new Mock<IAsyncCursor<Artifact>>();
        mockCursor.Setup(_ => _.Current).Returns(artifacts);
        mockCursor.SetupSequence(_ => _.MoveNext(It.IsAny<CancellationToken>()))
                .Returns(true)
                .Returns(false); // End the enumeration

        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(true)
                .ReturnsAsync(false); // For async

        // 2. Mock IMongoCollection<Artifact>
        var mockCollection = new Mock<IMongoCollection<Artifact>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<Artifact>>(),
                It.IsAny<FindOptions<Artifact, Artifact>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        // Set up the mock client and settings
        var mockClient = new Mock<IMongoClient>();
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<Artifact>("artifacts", null))
                    .Returns(mockCollection.Object);

        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "artifacts",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ArtifactRepository(options, mockClient.Object);

        // Act
        var result = await repo.GetAllAsync();

        // Assert
        Assert.Single(result);
        Assert.Equal("Exhibit A", result[0].Title);
    }

    // Test for returning artifacts by id
    [Fact]
    public async Task GetArtifactByID_ReturnsCorrectArtifact()
    {
        // Arrange
        var artifacts = new List<Artifact>
        {
            new Artifact
            {
                Id = "1",
                Title = "Exhibit A",
                ArtistId = "101",
                Artist = new Artist { Id = "101", Name = "Alice Walker" },
                ProductNo = "A001",
                Framed = true,
                Size = "24x36",
                Medium = "Oil on Canvas",
                Price = 1200.00,
                SalePrice = 1000.00,
                OnSale = true,
                TypeId = "1",
                Type = new ArtifactType { Id = "1", Title = "Painting", Description = "Pigments on canvas or wood" },
                Colour = "Blue",
                Shape = "Rectangle",
                New = false,
                StaffPicks = true,
                ExhibitionId = "201",
                Exhibition = new Exhibition { Id = "201", Title = "Winter Collection" }
            }
        };

         // 1. Mock IAsyncCursor<Artifact>
        var mockCursor = new Mock<IAsyncCursor<Artifact>>();
        mockCursor.Setup(_ => _.Current).Returns(artifacts);
        mockCursor.SetupSequence(_ => _.MoveNext(It.IsAny<CancellationToken>()))
                .Returns(true)
                .Returns(false); // End the enumeration

        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(true)
                .ReturnsAsync(false); // For async

        // 2. Mock IMongoCollection<Artifact>
        var mockCollection = new Mock<IMongoCollection<Artifact>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<Artifact>>(),
                It.IsAny<FindOptions<Artifact, Artifact>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);


        // Set up the mock client and settings
        var mockClient = new Mock<IMongoClient>();
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<Artifact>("artifacts", null))
                    .Returns(mockCollection.Object);

        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "artifacts",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ArtifactRepository(options, mockClient.Object);

        // Act
        var result = await repo.GetByIdAsync("1");  

        // Assert
        Assert.NotNull(result);
        Assert.Equal("Exhibit A", result.Title);
    }

    // Test for returning artifacts by id but designed to fail since it's not found
    [Fact]
    public async Task GetArtifactByID_ReturnsNullIfNotFound()
    {
        // 1. Mock IAsyncCursor<Artifact>
        var mockCursor = new Mock<IAsyncCursor<Artifact>>();
        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(false); // End the enumeration & async

        // Even though MoveNextAsync returns false, MongoDB driver might still access Current, so it must be set
        mockCursor.SetupGet(_ => _.Current).Returns(new List<Artifact>());

        // 2. Mock IMongoCollection<Artifact>
        var mockCollection = new Mock<IMongoCollection<Artifact>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<Artifact>>(),
                It.IsAny<FindOptions<Artifact, Artifact>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        // Set up the mock client and settings
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<Artifact>("artifacts", null))
                    .Returns(mockCollection.Object);

        var mockClient = new Mock<IMongoClient>();
        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "artifacts",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ArtifactRepository(options, mockClient.Object);

        // Act
        var result = await repo.GetByIdAsync("99");

        // Assert
        Assert.Null(result);
    }

    // Test for inserting new artifact into DB
    [Fact]
    public async Task InsertArtifacts_InsertsAndReturnsArtifact_WhenNotExists()
    {
        // Arrange
        var artifactToUpdate = new Artifact
        {
            Id = "1",
            Title = "Exhibit A",
            ArtistId = "101",
            Artist = new Artist { Id = "101", Name = "Alice Walker" },
            ProductNo = "A001",
            Framed = true,
            Size = "24x36",
            Medium = "Oil on Canvas",
            Price = 1200.00,
            SalePrice = 1000.00,
            OnSale = true,
            TypeId = "1",
            Type = new ArtifactType { Id = "1", Title = "Painting", Description = "Pigments on canvas or wood" },
            Colour = "Blue",
            Shape = "Rectangle",
            New = false,
            StaffPicks = true,
            ExhibitionId = "201",
            Exhibition = new Exhibition { Id = "201", Title = "Winter Collection" }
        };

        // 1. Mock IAsyncCursor<Artifact>
        var mockCursor = new Mock<IAsyncCursor<Artifact>>();
        mockCursor.Setup(_ => _.Current).Returns(new List<Artifact>());
        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(true)
                .ReturnsAsync(false); // End the enumeration & async

        // 2. Mock IMongoCollection<Artifact>
        var mockCollection = new Mock<IMongoCollection<Artifact>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<Artifact>>(),
                It.IsAny<FindOptions<Artifact, Artifact>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        mockCollection.Setup(c => c.ReplaceOneAsync(
                It.IsAny<FilterDefinition<Artifact>>(),
                artifactToUpdate,
                It.IsAny<ReplaceOptions>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(new ReplaceOneResult.Acknowledged(1, 1, artifactToUpdate.Id));

        // Set up the mock client and settings
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<Artifact>("artifacts", null))
                    .Returns(mockCollection.Object);

        var mockClient = new Mock<IMongoClient>();
        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "artifacts",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ArtifactRepository(options, mockClient.Object);
        
        // Act
        var result = await repo.InsertAsync(artifactToUpdate, false);

        // Assert
        Assert.NotNull(result);
        Assert.Equal("Exhibit A", result.Title);
    }

    // Test for inserting new artifact into DB but it already exists
    [Fact]
    public async Task InsertArtifacts_ReturnsNull_WhenArtifactAlreadyExists()
    {
        // Arrange
        var existingArtifact = new Artifact
        {
            Id = "1",
            Title = "Exhibit A",
            ArtistId = "101",
            Artist = new Artist { Id = "101", Name = "Alice Walker" },
            ProductNo = "A001",
            Framed = true,
            Size = "24x36",
            Medium = "Oil on Canvas",
            Price = 1200.00,
            SalePrice = 1000.00,
            OnSale = true,
            TypeId = "1",
            Type = new ArtifactType { Id = "1", Title = "Painting", Description = "Pigments on canvas or wood" },
            Colour = "Blue",
            Shape = "Rectangle",
            New = false,
            StaffPicks = true,
            ExhibitionId = "201",
            Exhibition = new Exhibition { Id = "201", Title = "Winter Collection" }
        };
        var artifactToUpdate = new Artifact
        {
            Id = "2",
            Title = "Urban Dream",
            ArtistId = "102",
            Artist = new Artist { Id = "102", Name = "Ben Carter" },
            ProductNo = "A002",
            Framed = false,
            Size = "18x24",
            Medium = "Acrylic",
            Price = 800.00,
            SalePrice = null,
            OnSale = false,
            TypeId = "2",
            Type = new ArtifactType { Id = "2", Title = "Sketch", Description = "Pencil and ink sketches" },
            Colour = "Monochrome",
            Shape = "Square",
            New = true,
            StaffPicks = false,
            ExhibitionId = null,
            Exhibition = null
        };

        // 1. Mock IAsyncCursor<Artifact>
        var mockCursor = new Mock<IAsyncCursor<Artifact>>();
        mockCursor.Setup(_ => _.Current).Returns(new List<Artifact> { existingArtifact });
        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(true)
                .ReturnsAsync(false); // End the enumeration & async

        // 2. Mock IMongoCollection<Artifact>
        var mockCollection = new Mock<IMongoCollection<Artifact>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<Artifact>>(),
                It.IsAny<FindOptions<Artifact, Artifact>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        // Set up the mock client and settings
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<Artifact>("artifacts", null))
                    .Returns(mockCollection.Object);

        var mockClient = new Mock<IMongoClient>();
        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "artifacts",
            ConnectionURI = "mongodb://localhost:27017"
        });
        
        var repo = new ArtifactRepository(options, mockClient.Object);
        
        // Act
        var result = await repo.InsertAsync(existingArtifact, false);

        // Assert
        Assert.Null(result); 
    }

    //Test to update artifact that exists
    [Fact]
    public async void UpdateArtifacts_UpdatesAndReturnsArtifact()
    {
        // Arrange
        var artifactToUpdate = new Artifact
        {
            Id = "1",
            Title = "Exhibit A",
            ArtistId = "101",
            Artist = new Artist { Id = "101", Name = "Alice Walker" },
            ProductNo = "A001",
            Framed = true,
            Size = "24x36",
            Medium = "Oil on Canvas",
            Price = 1200.00,
            SalePrice = 1000.00,
            OnSale = true,
            TypeId = "1",
            Type = new ArtifactType { Id = "1", Title = "Painting", Description = "Pigments on canvas or wood" },
            Colour = "Blue",
            Shape = "Rectangle",
            New = false,
            StaffPicks = true,
            ExhibitionId = "201",
            Exhibition = new Exhibition { Id = "201", Title = "Winter Collection" }
        };

        // 1. Mock IAsyncCursor<Artifact>
        var mockCursor = new Mock<IAsyncCursor<Artifact>>();
        mockCursor.Setup(_ => _.Current).Returns(new List<Artifact>());
        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(true)
                .ReturnsAsync(false); // End the enumeration & async

        // 2. Mock IMongoCollection<Artifact>
        var mockCollection = new Mock<IMongoCollection<Artifact>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<Artifact>>(),
                It.IsAny<FindOptions<Artifact, Artifact>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        mockCollection.Setup(c => c.ReplaceOneAsync(
                It.IsAny<FilterDefinition<Artifact>>(),
                artifactToUpdate,
                It.IsAny<ReplaceOptions>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(new ReplaceOneResult.Acknowledged(1, 1, artifactToUpdate.Id));

        // Set up the mock client and settings
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<Artifact>("artifacts", null))
                    .Returns(mockCollection.Object);

        var mockClient = new Mock<IMongoClient>();
        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "artifacts",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ArtifactRepository(options, mockClient.Object);

        // Act
        var result = await repo.UpdateAsync(artifactToUpdate, false);

        // Assert
        Assert.NotNull(result);
        Assert.Equal("Exhibit A", result.Title);
    }

    // Updates artifact but returns null since it doesn't exist
    [Fact]
    public async void UpdateArtifacts_ReturnsNull_OnException()
    {
        // Arrange
        var artifact = new Artifact
        {
            Id = "1",
            Title = "Exhibit A",
            ArtistId = "101",
            Artist = new Artist { Id = "101", Name = "Alice Walker" },
            ProductNo = "A001",
            Framed = true,
            Size = "24x36",
            Medium = "Oil on Canvas",
            Price = 1200.00,
            SalePrice = 1000.00,
            OnSale = true,
            TypeId = "1",
            Type = new ArtifactType { Id = "1", Title = "Painting", Description = "Pigments on canvas or wood" },
            Colour = "Blue",
            Shape = "Rectangle",
            New = false,
            StaffPicks = true,
            ExhibitionId = "201",
            Exhibition = new Exhibition { Id = "201", Title = "Winter Collection" }
        };
        var artifactToUpdate = new Artifact
        {
            Id = "2",
            Title = "Urban Dream",
            ArtistId = "102",
            Artist = new Artist { Id = "102", Name = "Ben Carter" },
            ProductNo = "A002",
            Framed = false,
            Size = "18x24",
            Medium = "Acrylic",
            Price = 800.00,
            SalePrice = null,
            OnSale = false,
            TypeId = "2",
            Type = new ArtifactType { Id = "2", Title = "Sketch", Description = "Pencil and ink sketches" },
            Colour = "Monochrome",
            Shape = "Square",
            New = true,
            StaffPicks = false,
            ExhibitionId = null,
            Exhibition = null
        };

        // 1. Mock IAsyncCursor<Artifact>
        var mockCursor = new Mock<IAsyncCursor<Artifact>>();
        mockCursor.Setup(_ => _.Current).Returns(new List<Artifact> {artifact});
        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(true)
                .ReturnsAsync(false); // End the enumeration & async

        // 2. Mock IMongoCollection<Artifact>
        var mockCollection = new Mock<IMongoCollection<Artifact>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<Artifact>>(),
                It.IsAny<FindOptions<Artifact, Artifact>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        mockCollection.Setup(c => c.ReplaceOneAsync(
                It.IsAny<FilterDefinition<Artifact>>(),
                artifactToUpdate,
                It.IsAny<ReplaceOptions>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(new ReplaceOneResult.Acknowledged(1, 1, artifactToUpdate.Id));

        // Set up the mock client and settings
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<Artifact>("artifacts", null))
                    .Returns(mockCollection.Object);

        var mockClient = new Mock<IMongoClient>();
        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "artifacts",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ArtifactRepository(options, mockClient.Object);

        // Act
        var result = await repo.UpdateAsync(artifactToUpdate, false);

        // Assert
        Assert.Null(result); 
    }

    // Test for deleting artifact
    [Fact]
    public async Task DeleteArtifacts_DeletesArtifact()
    {
        // Arrange: Mock empty cursor for FindAsync (no artifact found)
        var mockCursor = new Mock<IAsyncCursor<Artifact>>();
        mockCursor.Setup(_ => _.Current).Returns(new List<Artifact>());
        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(true)
                .ReturnsAsync(false);

        // Mock IMongoCollection<Artifact>
        var mockCollection = new Mock<IMongoCollection<Artifact>>();
        mockCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<Artifact>>(),
                It.IsAny<FindOptions<Artifact, Artifact>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        // Mock DeleteOneAsync to return a successful DeleteResult
        mockCollection.Setup(c => c.DeleteOneAsync(
                It.IsAny<FilterDefinition<Artifact>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Mock.Of<DeleteResult>(r => r.IsAcknowledged == true && r.DeletedCount == 1));

        // Set up the mock client and settings
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<Artifact>("artifacts", null))
                    .Returns(mockCollection.Object);

        var mockClient = new Mock<IMongoClient>();
        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "artifacts",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ArtifactRepository(options, mockClient.Object);

        // Act
        await repo.DeleteAsync("1");

        // Assert: Verify DeleteOneAsync was called once with correct filter
        mockCollection.Verify(c => c.DeleteOneAsync(
            It.Is<FilterDefinition<Artifact>>(f => true),  
            It.IsAny<CancellationToken>()), Times.Once);
    }

    // Test getting artifacts by type
    [Fact]
    public async Task GetArtifactsByTypeAsync_ReturnsMatchingArtifacts()
    {
        // Arrange
        string typeTitle = "Installation";
        var expectedArtifacts = new List<Artifact>
        {
            new Artifact
            {
                Id = "1",
                Title = "Fragmented Reflections",
                Type = new ArtifactType { Title = "Installation" }
            }
        };

        // 1. Mock IAsyncCursor<Artifact>
        var mockCursor = new Mock<IAsyncCursor<Artifact>>();
        mockCursor.Setup(_ => _.Current).Returns(expectedArtifacts);
        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(true)
                .ReturnsAsync(false); // End the enumeration & async

        // 2. Mock IMongoCollection<Artifact>
        var mockCollection = new Mock<IMongoCollection<Artifact>>();
        mockCollection.Setup(c => c.FindAsync(
            It.IsAny<FilterDefinition<Artifact>>(),
            It.IsAny<FindOptions<Artifact, Artifact>>(),
            It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        // Set up the mock client and settings
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<Artifact>("artifacts", null))
                    .Returns(mockCollection.Object);

        var mockClient = new Mock<IMongoClient>();
        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "artifacts",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ArtifactRepository(options, mockClient.Object);

        // Act
        var result = await repo.GetArtifactsByTypeAsync(typeTitle);

        // Assert
        Assert.Single(result);
        Assert.Equal("Fragmented Reflections", result[0].Title);
        Assert.Equal("Installation", result[0].Type.Title);
    }

    // Test for getting filtered artifacts
    [Fact]
    public async Task GetFilteredArtifactsAsync_FramedTrue_ReturnsFramedArtifacts()
    {
        // Arrange
        var framedArtifacts = new List<Artifact>
        {
            new Artifact { Id = "1", Title = "Sunset", Framed = true },
            new Artifact { Id = "2", Title = "Mountain View", Framed = true }
        };

        // 1. Mock IAsyncCursor<Artifact>
        var mockCursor = new Mock<IAsyncCursor<Artifact>>();
        mockCursor.Setup(_ => _.Current).Returns(framedArtifacts);
        mockCursor.SetupSequence(_ => _.MoveNextAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(true)
                .ReturnsAsync(false); // End the enumeration & async

        // 2. Mock IMongoCollection<Artifact>
        var mockCollection = new Mock<IMongoCollection<Artifact>>();
        mockCollection.Setup(c => c.FindAsync(
            It.IsAny<FilterDefinition<Artifact>>(),
            It.IsAny<FindOptions<Artifact, Artifact>>(),
            It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockCursor.Object);

        // Set up the mock client and settings
        var mockDatabase = new Mock<IMongoDatabase>();
        mockDatabase.Setup(db => db.GetCollection<Artifact>("artifacts", null))
                    .Returns(mockCollection.Object);

        var mockClient = new Mock<IMongoClient>();
        mockClient.Setup(c => c.GetDatabase("Mongo", null))
                .Returns(mockDatabase.Object);

        var options = Options.Create(new MongoDbSettings
        {
            DatabaseName = "Mongo",
            CollectionName = "artifacts",
            ConnectionURI = "mongodb://localhost:27017"
        });

        var repo = new ArtifactRepository(options, mockClient.Object);

        // Act
        var result = await repo.GetFilteredArtifactsAsync(true, null, null);

        // Assert
        Assert.Equal(2, result.Count);
        Assert.All(result, a => Assert.True(a.Framed));
    }
}