using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace art_api.Models;
public class Exhibition
{
    [BsonId]
    [BsonRepresentation(BsonType.ObjectId)]
    public string Id { get; set; }
    
    [BsonElement("title")]
    public string Title { get; set; } = string.Empty;
    
    [BsonElement("startdate")]
    public DateTime StartDate { get; set; }
   
    [BsonElement("enddate")]
    public DateTime EndDate { get; set; }
    
    [BsonElement("description")]
    public string? Description { get; set; } = string.Empty;
    
    [BsonElement("current")]
    public bool Current { get; set; }
}