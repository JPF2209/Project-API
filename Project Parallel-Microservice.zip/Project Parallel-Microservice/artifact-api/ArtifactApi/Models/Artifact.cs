using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace art_api.Models
{
    public class Artifact
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string? Id { get; set; }

        [BsonElement("title")]
        public string Title { get; set; } = null!;

        [BsonElement("artistId")]
        public string ArtistId { get; set; } = null!;

        [BsonElement("productNo")]
        public string ProductNo { get; set; } = null!;

        [BsonElement("framed")]
        public bool Framed { get; set; }

        [BsonElement("size")]
        public string Size { get; set; } = null!;

        [BsonElement("medium")]
        public string Medium { get; set; } = null!;

        [BsonElement("price")]
        public double Price { get; set; }

        [BsonElement("salePrice")]
        public double? SalePrice { get; set; }

        [BsonElement("onSale")]
        public bool OnSale { get; set; }

        [BsonElement("typeId")]
        public string TypeId { get; set; } = null!;

        [BsonElement("type")]
        public ArtifactType? Type { get; set; } 
        
        [BsonElement("colour")]
        public string Colour { get; set; } = null!;

        [BsonElement("shape")]
        public string Shape { get; set; } = null!;

        [BsonElement("new")]
        public bool New { get; set; }

        [BsonElement("staffPicks")]
        public bool StaffPicks { get; set; }

        [BsonElement("exhibitionId")]
        public string? ExhibitionId { get; set; }

        [BsonElement("artist")]
        public Artist? Artist { get; set; } 

        [BsonElement("exhibition")]
        public Exhibition? Exhibition { get; set; } 
    }
}
