using MongoDB.Driver;
using MongoDB.Bson;
using Microsoft.Extensions.Options;
using MongoDB.Bson.Serialization.Attributes;

using art_api.Models;
using art_api.Settings;

namespace art_api.Persistence
{
    public class ExhibitionRepository : IExhibitionRepository
    {
        private readonly IMongoCollection<Exhibition> _collection;

        public ExhibitionRepository(IOptions<MongoDbSettings> settings, IMongoClient client)
        {
            var db = client.GetDatabase(settings.Value.DatabaseName); // e.g., "Mongo"
            _collection = db.GetCollection<Exhibition>("exhibitions");
        }

        public async Task<Exhibition?> GetByTitleAsync(string title)
        {
            return await _collection.Find(a => a.Title == title).FirstOrDefaultAsync();
        }

        public async Task<Exhibition> InsertAsync(Exhibition exhibition, bool isChecked)
        {
            // For Xunit test, check if not in DB
            if (isChecked == false)
            {
                var existingExhibition = await _collection.Find(a => a.Title == exhibition.Title).FirstOrDefaultAsync();

                if (existingExhibition != null)
                {
                    return null;
                }
            }
            await _collection.InsertOneAsync(exhibition);
            return exhibition;
        }

        public async Task<List<Exhibition>> GetAllAsync()
        {
            return await _collection.Find(_ => true).ToListAsync();
        }

        public async Task<Exhibition?> GetByIdAsync(string id)
        {
            return await _collection.Find(a => a.Id == id).FirstOrDefaultAsync();
        }

        public async Task<List<Exhibition>> GetByCurrentAsync(bool current)
        {
            return await _collection.Find(a => a.Current == current).ToListAsync();
        }

        public async Task<Exhibition> UpdateAsync(Exhibition exhibition, bool isChecked)
        {
            // For Xunit test, check if in DB
            if (isChecked == false)
            {
                var existingExhibition = await _collection.Find(a => a.Title == exhibition.Title).FirstOrDefaultAsync();

                if (existingExhibition != null)
                {
                    return null;
                }
            }
            var filter = Builders<Exhibition>.Filter.Eq(a => a.Id, exhibition.Id);
            var result = await _collection.ReplaceOneAsync(filter, exhibition);

            // If it updated, return exhibition
            if (result.IsAcknowledged && result.ModifiedCount > 0)
                return exhibition;

            return null; //Update failed
        }

        public async Task<bool> DeleteAsync(string id)
        {
            var result = await _collection.DeleteOneAsync(a => a.Id == id);
            return result.DeletedCount > 0;
        }
    }
}
