using System.Threading.Tasks;
using art_api.Models;
using art_api.Persistence;

namespace art_api.Services
{
    public class ExhibitionDataAccess : IExhibitionDataAccess
    {
        private readonly IExhibitionRepository _exhibitionRepository;

        public ExhibitionDataAccess(IExhibitionRepository exhibitionRepository)
        {
            _exhibitionRepository = exhibitionRepository;
        }

        public Task<List<Exhibition>> GetAllExhibitionsAsync() 
        {
            return _exhibitionRepository.GetAllAsync();
        }

        public Task<Exhibition?> GetExhibitionByIdAsync(string id)
        {
            return _exhibitionRepository.GetByIdAsync(id);
        }

        public Task<List<Exhibition>> GetExhibitionByCurrentAsync(bool current)
        {
            return _exhibitionRepository.GetByCurrentAsync(current);
        }

        public async Task<Exhibition?> InsertExhibitionAsync(Exhibition exhibition)
        {
            //Checks if exhibition doesn't exist
            var existing = await _exhibitionRepository.GetByTitleAsync(exhibition.Title);
            if (existing != null)
            {
                return null;
            }

            return await _exhibitionRepository.InsertAsync(exhibition, true);
        }

        public async Task<Exhibition?> UpdateExhibitionAsync(Exhibition exhibition)
        {
            // Checks if exhibiton exists
            var existing = await _exhibitionRepository.GetByTitleAsync(exhibition.Title);
            if (existing == null)
            {
                return null;
            }
            return await _exhibitionRepository.UpdateAsync(exhibition, true);
        }

        public async Task<bool> DeleteExhibitionAsync(string id)
        {
            return await _exhibitionRepository.DeleteAsync(id);
        }
    }
}