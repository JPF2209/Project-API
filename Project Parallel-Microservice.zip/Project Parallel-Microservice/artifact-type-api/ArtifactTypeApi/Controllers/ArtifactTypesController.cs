using Microsoft.AspNetCore.Mvc;
using art_api.Services;
using art_api.Models;

namespace art_api.Controllers;

[ApiController]
[Route("api/artifactType")]
public class ArtifactTypesController : ControllerBase
{
    private readonly IArtifactTypeDataAccess _artifactTypesRepo;
    
    public ArtifactTypesController(IArtifactTypeDataAccess artifactTypesRepo)
    {
        _artifactTypesRepo = artifactTypesRepo;
    }

    // Controller for getting all artifact typess
    [HttpGet("")]
    public async Task<ActionResult<IEnumerable<ArtifactType>>> GetAll()
    {
        var artifactTypes = await _artifactTypesRepo.GetAllArtifactTypesAsync();
        return Ok(artifactTypes);
    }

    // Controller for getting artifact types by id
    [HttpGet("{id}", Name = "GetArtifactType")]
    public async Task<ActionResult<ArtifactType>> GetById(string id)
    {
        var artifactType = await _artifactTypesRepo.GetArtifactTypeByIdAsync(id);
        // If it's null, it's not found
        if (artifactType == null)
            return NotFound();

        return Ok(artifactType);
    }

    // Controller for inserting artifact types
    [HttpPost]
    public async Task<IActionResult> AddArtifactType([FromBody] ArtifactType newArtifactType)
    {
        // If new artifact type is null it's a bad request
        if (newArtifactType == null)
        {
            return BadRequest("ArtifactType is null.");
        }

        var artifactType = await _artifactTypesRepo.InsertArtifactTypeAsync(newArtifactType);
        
        // If the inserted value is null, a check was made and the artifact type already exists
        if (artifactType == null)
        {
            return Conflict("ArtifactType already exists.");
        }

        return CreatedAtRoute("GetArtifactType", new { id = artifactType.Id }, artifactType);
    }

    // Controller for updating artifact types
    [HttpPut("{id}")]
    public async Task<IActionResult> Update(string id, [FromBody] ArtifactType updatedArtifactType)
    {
        // If updated artifact type id doesn't match what in the body or if the body is null
        if (id != updatedArtifactType.Id)
            return BadRequest();

        var result = await _artifactTypesRepo.UpdateArtifactTypeAsync(updatedArtifactType);

        // If artifact type it's searching for doesn't exist or if there's a duplicate title for the artifact
        if (result == null)
            return NotFound();

        return Ok(result);
    }

    // Controller for deleting artifact types
    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(string id)
    {
        var deleted = await _artifactTypesRepo.DeleteArtifactTypeAsync(id);
        
        // If not a success (bool), the id didn't exist
        if (!deleted)
            return NotFound();

        return NoContent(); 
    }
}
