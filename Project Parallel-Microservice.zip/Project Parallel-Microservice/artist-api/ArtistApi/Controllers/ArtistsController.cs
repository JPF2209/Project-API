using Microsoft.AspNetCore.Mvc;
using art_api.Services;
using art_api.Models;

namespace art_api.Controllers;

[ApiController]
[Route("api/artist")]
public class ArtistsController : ControllerBase
{
    private readonly IArtistDataAccess _artistsRepo;
    public ArtistsController(IArtistDataAccess artistsRepo)
    {
        _artistsRepo = artistsRepo;
    }

    // Controller for getting all artists
    [HttpGet("")]
    public async Task<ActionResult<IEnumerable<Artist>>> GetAll()
    {
        var artists = await _artistsRepo.GetAllArtistsAsync();
        return Ok(artists);
    }

    // Controller for getting artists by id
    [HttpGet("{id}", Name = "GetArtist")]
    public async Task<ActionResult<Artist>> GetById(string id)
    {
        var artist = await _artistsRepo.GetArtistByIdAsync(id);
        // If it's null, it's not found
        if (artist == null)
            return NotFound();

        return Ok(artist);
    }

    // Controller for getting artists by community
    [HttpGet("by-community")]
    public async Task<ActionResult<Artist>> GetArtistsByCommunity(string community)
    {
        var artist = await _artistsRepo.GetArtistByCommunityAsync(community); 
        
        // If the inserted value is null, the community isn't in any artist
        if (artist == null)
            return NotFound();
        return Ok(artist);
    }

    // Controller for inserting artists
    [HttpPost]
    public async Task<IActionResult> AddArtist([FromBody] Artist newArtist)
    {
        // If new artist is null it's a bad request
        if (newArtist == null)
        {
            return BadRequest("Artist is null.");
        }

        var artist = await _artistsRepo.InsertArtistAsync(newArtist);
        
        // If the inserted value is null, a check was made and the artist already exists
        if (artist == null)
        {
            return Conflict("Artist already exists.");
        }

        return CreatedAtRoute("GetArtist", new { id = artist.Id }, artist);
    }

    // Controller for updating artists
    [HttpPut("{id}")]
    public async Task<IActionResult> Update(string id, [FromBody] Artist updatedArtist)
    {
        // If updated artist id doesn't match what in the body or if the body is null
        if (id != updatedArtist.Id)
            return BadRequest();

        var result = await _artistsRepo.UpdateArtistAsync(updatedArtist);

        // If artist it's searching for doesn't exist or if there's a duplicate title for the artist
        if (result == null)
            return NotFound();

        return Ok(result);
    }

    // Controller for deleting artists
    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(string id)
    {
        var deleted = await _artistsRepo.DeleteArtistAsync(id);
        
        // If not a success (bool), the id didn't exist
        if (!deleted)
            return NotFound();

        return NoContent(); 
    }
}
