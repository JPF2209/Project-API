using System.Collections.Generic;
using art_api.Models;

namespace art_api.Services
{
    public interface IArtifactDataAccess
    {
        Task<List<Artifact>> GetAllArtifactsAsync(); 
        Task<Artifact?> GetArtifactByIdAsync(string id);
        Task<Artifact?> InsertArtifactAsync(Artifact artifact);
        Task<Artifact?> UpdateArtifactAsync(Artifact artifact);
        Task<bool> DeleteArtifactAsync(string id); 
        Task<List<Artifact>> GetFilteredArtifactsAsync(bool? framed, bool? @new, bool? staffPick); // <-- new
        Task<List<Artifact>> GetArtifactsByTypeAsync(string typeTitle);
    }
}
