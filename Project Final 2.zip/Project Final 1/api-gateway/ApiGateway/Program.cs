using Ocelot.DependencyInjection;
using Ocelot.Middleware;

var builder = WebApplication.CreateBuilder(args);

// 1. Load Ocelot Configuration File
// Set to optional: false to crash on startup if the file is missing (good for diagnosing)
builder.Configuration.AddJsonFile("ocelot.json", optional: false, reloadOnChange: true);

// 2. Add Ocelot Services
builder.Services.AddOcelot();

var app = builder.Build();

// 3. Simple Test Route (for confirmation, placed before Ocelot middleware)
// This will only work if Ocelot allows it, or if it runs before Ocelot takes over.
app.MapGet("/", () => "API Gateway is Running!");

// 4. CRITICAL: Use Ocelot Middleware
// This must be placed near the end of the pipeline, before app.Run().
// We use .Wait() to ensure the async configuration process completes.
app.UseOcelot().Wait(); 

app.Run();
