// This class holds the specific collection name for Dependency Injection (DI) configuration,
// separating it from the general MongoDB connection settings.

namespace art_api.Settings
{
    // Interface for the collection-specific settings
    public interface IArtifactTypeCollectionSettings
    {
        string CollectionName { get; set; }
    }

    public class ArtifactTypeCollectionSettings : IArtifactTypeCollectionSettings
    {
        // Must contain a non-null value upon exiting constructor
        public string CollectionName { get; set; } = string.Empty;
    }
}