using Microsoft.AspNetCore.Mvc;
using art_api.Services;
using art_api.Models;

namespace art_api.Controllers
{
    [ApiController]
    [Route("api/artifact")]
    public class ArtifactsController : ControllerBase
    {
        private readonly IArtifactDataAccess _artifactAccess;

        public ArtifactsController(IArtifactDataAccess artifactAccess)
        {
            _artifactAccess = artifactAccess;
        }

        // Controller for getting all artifacts
        [HttpGet("")]
        public async Task<ActionResult<IEnumerable<Artifact>>> GetAllArtifacts()
        {
            var artifacts = await _artifactAccess.GetAllArtifactsAsync();
            return Ok(artifacts);
        }

        // Controller for getting artifacts by id
        [HttpGet("{id}", Name = "GetArtifact")]
        public async Task<ActionResult<Artifact>> GetArtifactById(string id)
        {
            var artifact = await _artifactAccess.GetArtifactByIdAsync(id);
            
            // If it's null, it's not found
            if (artifact == null)
                return NotFound();

            return Ok(artifact);
        }

        // Controller for getting filtered artifacts (framed, new or staffpick)
        [HttpGet("artifacts/by-filter")]
        public async Task<ActionResult<IEnumerable<Artifact>>> GetFilteredArtifacts(
            [FromQuery] bool? framed,
            [FromQuery] bool? @new,
            [FromQuery] bool? staffPick)
        {
            var artifacts = await _artifactAccess.GetFilteredArtifactsAsync(framed, @new, staffPick);
            return Ok(artifacts);
        }

        // Controller for getting artifacts by type
        [HttpGet("artifacts/by-type")]
        public async Task<ActionResult<IEnumerable<Artifact>>> GetArtifactsByType([FromQuery] string typeTitle)
        {
            // Returns bad request if typeTitle is null
            if (string.IsNullOrWhiteSpace(typeTitle))
                return BadRequest();

            var artifacts = await _artifactAccess.GetArtifactsByTypeAsync(typeTitle);
            return Ok(artifacts);
        }

        // Controller for inserting artifacts
        [HttpPost]
        public async Task<ActionResult<Artifact>> AddArtifact([FromBody] Artifact newArtifact)
        {
            // If new artifact is null it's a bad request
            if (newArtifact == null)
                return BadRequest();

            var inserted = await _artifactAccess.InsertArtifactAsync(newArtifact);
            
            // If the inserted value is null, a check was made and the artifact already exists
            if (inserted == null)
                return Conflict("Artifact with the same title already exists.");

            return CreatedAtRoute("GetArtifact", new { id = inserted.Id }, inserted);
        }

        // Controller for updating artifacts
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateArtifact(string id, [FromBody] Artifact updatedArtifact)
        {
            // If updated artifact id doesn't match what in the body or if the body is null
            if (updatedArtifact == null || id != updatedArtifact.Id)
                return BadRequest();

            var updated = await _artifactAccess.UpdateArtifactAsync(updatedArtifact);
            
            // If artifact it's searching for doesn't exist or if there's a duplicate title for the artifact
            if (updated == null)
                return NotFound();

            return NoContent();
        }

        // Controller for deleting artifacts
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteArtifact(string id)
        {
            var success = await _artifactAccess.DeleteArtifactAsync(id);
            
            // If not a success (bool), the id didn't exist
            if (!success)
                return NotFound();

            return NoContent();
        }
    }
}